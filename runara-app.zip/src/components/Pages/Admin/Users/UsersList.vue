<script setup lang="ts">

</script>

<template>
  <button>Liste des utilisateurs</button>
</template>

<style scoped>

</style>